/******************************************************************************

Escreva um algoritmo que leia 3 números a partir do teclado. O algoritmo deve
apresentar:
a. O maior número.
b. O menor número.
c. A média aritmética dos três números.

*******************************************************************************/
using System;
class HelloWorld {
  static void Main() {
    int[] numeros = new int[3];
    int menor = 0, maior = 0;
    Console.WriteLine("Digite 3 numeros para saber qual é o maior, o menos e a média: ");
    for (int i = 0; i < numeros.Length; i++)
    {
        numeros[i] = int.Parse(Console.ReadLine());
    }
    maior = numeros[0];
    menor = numeros[0];
    for(int i = 0; i < numeros.Length; i++)
    {
        if(numeros[i]>=maior)
            maior = numeros[i];
        if(numeros[i]<=menor)
            menor = numeros[i];
    }
    Console.WriteLine($"O maior número é o {maior}, o menor é o número {menor} a média dos 3 é: {(numeros[0]+numeros[1]+numeros[2])/3}");
  }
}