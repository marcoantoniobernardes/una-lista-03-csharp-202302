/******************************************************************************

Escreva um algoritmo que leia dois valores: o primeiro servindo de indicador de
operação e o segundo correspondendo ao raio de um círculo ou esfera. Caso o
primeiro valor lido seja:
a. 1: calcular e imprimir o perímetro do círculo.
b. 2: calcular e imprimir a área do círculo.
c. 3: calcular e imprimir o volume da esfera.
Se o primeiro valor lido for diferente desses três valores possíveis, imprimir uma
mensagem de erro, informando que o código da operação é inválido.

*******************************************************************************/
using System;
class HelloWorld {
  static void Main() {
    double raio, i;
    Console.WriteLine("Circulo, digite o raio do circulo");
    raio = double.Parse(Console.ReadLine());
    Console.WriteLine("Para calcular o perímetro digite (1), para calcular área (2), e o volume (3) ");
    i = int.Parse(Console.ReadLine());
    if(i ==1 )
        Console.WriteLine($"O perímetro do circulo é {2*3.14*raio}");
    else if(i == 2)
        Console.WriteLine($"A área do circulo é {3.14*raio*raio}");
    else
        Console.WriteLine($"O volume da esfera é {(4/3)*3.14*raio*raio*raio}");
    Console.ReadLine();
  }
}