/******************************************************************************

Escrever um algoritmo que leia a partir do teclado dois números reais e um dos
símbolos de operação: + , - , * , / ou ^ .
O algoritmo deve retornar o resultado da operação.
Caso o símbolo informado seja diferente dos símbolos preestabelecidos, o algoritmo
deve apresentar uma mensagem de erro, informando que o símbolo da operação é
inválido.

*******************************************************************************/
using System;
class HelloWorld {
  static void Main() {
    double num1 = 0, num2 = 0;
    Console.WriteLine("Digite dois números:");
    num1 = double.Parse(Console.ReadLine());
    num2 = double.Parse(Console.ReadLine());
    Console.WriteLine("Digite o simbolo da operação");
    string simbolo = Console.ReadLine();
    if (simbolo.Equals("+"))
        Console.WriteLine($"A soma é: {num1 + num2}");
    else if (simbolo.Equals("-"))
        Console.WriteLine($"A subtração é: {num1 - num2}");
    else if (simbolo.Equals("*"))
        Console.WriteLine($"A multiplicação é: {num1 * num2}");
    else if (simbolo.Equals("/"))
        Console.WriteLine($"A divisão é: {num1 / num2}");
    else if simbolo.Equals("^")
        Console.WriteLine($"A potencia é: {Math.Pow(num1, num2)}");
    else
        Console.WriteLine("Informo que o símbolo da operação é inválido");
    Console.ReadLine();
  }
}