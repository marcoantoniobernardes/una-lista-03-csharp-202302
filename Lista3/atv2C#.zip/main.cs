/******************************************************************************

Escreva o algoritmo de uma máquina de venda automática de salgadinhos, doces,
sucos e refrigerantes. O algoritmo deve calcular o menor número de notas que deve
ser dado de troco para um pagamento efetuado.
O algoritmo deve ler o valor da compra e o valor pago.
Se o valor pago for menor que o valor da compra, a máquina deve apresentar uma
mensagem, informando que a quantia paga é insuficiente para realizar a compra. 

*******************************************************************************/
using System;
class HelloWorld {
  static void Main() {
    int valorCompra = 0, valorPago = 0, troco = 0;
        // Define as denominações das notas
    int[] notas = { 100, 50, 20, 10, 5, 2, 1 };
    Console.WriteLine("Valor da compra");
    valorCompra = int.Parse(Console.ReadLine());
    Console.WriteLine("Valor pago");
    valorPago = int.Parse(Console.ReadLine());
        // Calcula o troco
    troco = valorPago - valorCompra;
        // Calcula a quantidade de cada nota no troco
    Console.WriteLine("Confira o troco voçê recebera:");
    foreach (var nota in notas)
    {
        int quantidadeNotas = (troco / nota);
        if (quantidadeNotas > 0)
        {
            Console.WriteLine($"{quantidadeNotas} nota(s) de {nota:C}: ");
            troco %= nota;
        }
    }
  }
}