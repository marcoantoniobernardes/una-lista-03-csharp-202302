/******************************************************************************

Crie um algoritmo que leia dois números inteiros e realize o sorteio de um número
aleatório. O algoritmo deve validar qual é o menor e o maior número informado pelo
teclado, para que independente da ordem que o usuário digite os números, consiga
realizar o sorteio.
Se o algoritmo gerar um número par, escreva na tela o número gerado e informe que
ele é par. Se o algoritmo gerar um número ímpar, escreva na tela o número gerado e
que ele é um número ímpar

*******************************************************************************/
using System;
class HelloWorld {
  static void Main() {
    int num1 = 0, num2 =0, numeroA = 0, menorN = 0,maiorN =0;
    Console.WriteLine("Digite dois numeros inicio , e fim para gerar un numero aleatório:");
    num1 = int.Parse(Console.ReadLine());
    num2 = int.Parse(Console.ReadLine());
    // Encontrar o menor e o maior número
    menorN = Math.Min(num1, num2);
    maiorN = Math.Max(num1, num2);
    // Gere um número aleatório entre o menor e o maior número
    Random random = new Random();
    numeroA = random.Next(menorN, maiorN + 1);
    //Confere se e impar ou par
    string resultado = (numeroA % 2 == 0) ? "Par" : "Ímpar";
    Console.WriteLine($"O número gerodo foi {numeroA} ele é: {resultado}");
    Console.ReadLine();
  }
}