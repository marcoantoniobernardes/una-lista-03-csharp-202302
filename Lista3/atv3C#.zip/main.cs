/******************************************************************************

Escreva um algoritmo que resolva uma equação de segundo grau, realizando a
verificação de consistência dos valores dos coeficientes ("a", "b" e "c") e do
discriminante (delta).
a. Se os coeficientes "a" e "b" forem iguais a zero e o coeficiente "c" for diferente de
zero, apresentar a mensagem "Coeficientes informados incorretamente.".
b. Caso o coeficiente "a" seja igual a zero e o coeficiente "b" for diferente de zero,
deverá ser impressa a mensagem: "Essa é uma equação de primeiro grau" e deverá
ser informado o valor da raiz real da equação.
c. Caso o discriminante seja negativo, deverá ser impressa a mensagem: "Esta
equação não possui raízes reais".
d. Caso o discriminante seja zero, apresentar a mensagem "Esta equação possui duas
raízes reais iguais. " e informar o valor das raízes da equação.
e. Caso o discriminante seja maior que zero, apresentar a mensagem "Esta equação
possui duas raízes reais diferentes. " e informar o valor das raízes da equação.

*******************************************************************************/
using System;
class HelloWorld {
  static void Main() {
    double a = 0, b = 0, c = 0, delta = 0, x1 = 0, x2 = 0, raiz = 0;
    Console.WriteLine("Equação de segundo grau, digite os coeficiente de a, b e c");
    a = double.Parse(Console.ReadLine());
    b = double.Parse(Console.ReadLine());
    c = double.Parse(Console.ReadLine());
    if(a == 0 && b == 0)
        Console.WriteLine("Coeficientes informados incorretamente.");
    if(a == 0 && b != 0)
    {
        Console.WriteLine("Essa é uma equação de primeiro grau");
        x1 = (-c/b);
        Console.WriteLine($"O valor de x é: {x1}");
    }
    else
    {
        delta = (b*b -4*a*c);
        raiz = Math.Sqrt(delta);
        x1 = (-b + raiz)/(2*a);
        x2 = (-b - raiz)/(2*a);
        Console.WriteLine($"O valor de x1 é: {x1} e x2 é: {x2}");
    }
    Console.ReadLine();
  }
}